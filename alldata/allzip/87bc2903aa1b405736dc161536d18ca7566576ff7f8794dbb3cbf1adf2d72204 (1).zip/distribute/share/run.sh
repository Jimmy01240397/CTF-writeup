#!/bin/bash

exec 2>/dev/null

timeout 99 /home/UnicornsAisle/unicornsAisle /home/UnicornsAisle/encounter.emu
