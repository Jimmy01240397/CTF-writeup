#ifndef __MAIN_HEADER__
#define __MAIN_HEADER__

#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<malloc.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unicorn/unicorn.h>
#include"utils.h"
#include"guestcontext.h"
#include"mem.h"
#include"ucutils.h"
#include"handler.h"

#endif
