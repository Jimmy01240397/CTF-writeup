#!/bin/bash
LD_LIBRARY_PATH=./unicorn/ ./unicornsAisle ./encounter.emu
