#!/bin/bash

exec python3 /home/${USERNAME}/chal.py 2>&1
